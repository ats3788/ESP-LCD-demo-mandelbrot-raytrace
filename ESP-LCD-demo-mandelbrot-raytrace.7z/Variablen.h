// Variablen.h

#ifndef _VARIABLEN_h
#define _VARIABLEN_h

#if defined(ARDUINO) && ARDUINO >= 100
	#include "arduino.h"
#else
	#include "WProgram.h"
#endif
#include <WROVER_KIT_LCD.h>
static WROVER_KIT_LCD tft;

#endif

